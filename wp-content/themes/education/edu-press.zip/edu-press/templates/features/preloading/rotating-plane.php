<?php
/**
 * Preload Template: rotated plane
 *
 * @package Edu_Press
 */
?>

<div class="sk-rotating-plane"></div>
